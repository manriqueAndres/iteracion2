/**
 * 
 */
/**
 * @author optitudes
 *
 */
module iteracion2 {
	requires java.desktop;
}