package iteracion2.models;

public class Adviser extends Persona{

	public Adviser(String name, String lastNames, String id, String password, String email) {
		super(name, lastNames, id, password, email);
	}

}
