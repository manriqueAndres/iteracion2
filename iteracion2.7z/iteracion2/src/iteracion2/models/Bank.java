package iteracion2.models;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;

public class Bank {
	private String nit = "12345";
	private ArrayList<Client> clientList = new ArrayList<>();
	private ArrayList<Account> accountList = new ArrayList<>();
	private ArrayList<Adviser> adviserList = new ArrayList<>();
	public Bank() {
		super();
	}
	public String registerUserWith(Client newClient, Account newAccount) {
		if(clientList.add(newClient) && accountList.add(newAccount)) {
			return "200,El usuario y la cuenta se han registrado con exito";
		}
		return "500,Error al registrar el nuevo usuario";
	}
	
	public String updateUserAccountAttribute(String names, String attributeToChange, String newValueToAtrribute) {
		for (Client client : clientList) {
			if(client.isNameEqualTo(names)) {
				client.updateAttribute(attributeToChange,newValueToAtrribute);
				return "200. datos actualizados con exito "+client.toString();
			}
		}
		return "500. cliente no encontrado";
	}
	public String deleteUserAccount(String accountId, String deleteReason, String password) {
		Account account = getAccountbyId(accountId);
		if(account != null) {
			Client accountClient = account.getAssociatedClient();
			if (accountClient.isPasswordEqualTo(password)) {
				clientList.remove(accountClient);
				accountList.remove(account);
				return "200. cuenta eliminada con exito";
			}
			return "500. clave incorrecta";
		}
		return "500. cuenta no encontrada";
	}
	private Account getAccountbyId(String idAccount) {
		return accountList.stream().filter(account -> account.isIdEqualTo(idAccount)).findFirst().orElse(null);
	}
	public String incrementAccountAmount(String accountId, String titularId, Double amountToIncrement) {
		Account account = getAccountbyId(accountId);
		if(account != null) {
			Client accountClient = account.getAssociatedClient();
			if(accountClient.isIdEqualTo(titularId)) {
				account.incrementCurrentMoney(amountToIncrement);
				return "200. saldo incrementado con exito, saldo actual:"+account.getCurrentMoney();
			}
			return "500. el id del usuario titular de la cuenta es incorrecto";
		}
		return "500. cuenta no encontrada";
	}
	public String transferMoney(String destinationAccountNumber, String amountString, String originAccountNumber,
			String password) {
		Double amount = Double.parseDouble(amountString);
		Account originAccount = getAccountbyId(originAccountNumber);
		if(originAccount != null) {
			Client accountClient = originAccount.getAssociatedClient();
			if(accountClient.isPasswordEqualTo(password)) {
				if (originAccount.isCurrentMoneyGreaterThan(amount)) {
					Account destinationAccount = getAccountbyId(destinationAccountNumber);
					if (destinationAccount != null ) {
						originAccount.decrementCurrentMoney(amount);
						destinationAccount.incrementCurrentMoney(amount);
						return "200. transaccion realizada con exito, saldo actual: "+originAccount.getCurrentMoney();
					}
					return "500. la cuenta destino no ha sido encontrada";
				}
				return "500. el saldo es insuficiente para hacer la transferencia";
			}
			return "500. la clave  del usuario titular de es incorrecta";
		}
		return "500. cuenta no encontrada";	
	}
	public String withdrawMoney(String titularId, String accountId, String amountAux, String password) {
		Account account = getAccountbyId(accountId);

		Double amount = Double.parseDouble(amountAux);
		if(account != null) {
			Client accountClient = account.getAssociatedClient();
			if(accountClient.isIdEqualTo(titularId)) {
				account.decrementCurrentMoney(amount);
				return "200. saldo retirado con exito, saldo actual:"+account.getCurrentMoney();
			}
			return "500. el id del usuario titular de la cuenta es incorrecto";
		}
		return "500. cuenta no encontrada";

	}
	
	
}
