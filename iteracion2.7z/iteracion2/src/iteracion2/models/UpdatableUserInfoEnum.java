package iteracion2.models;

public enum UpdatableUserInfoEnum {
	NOMBRES,APELLIDOS
}
