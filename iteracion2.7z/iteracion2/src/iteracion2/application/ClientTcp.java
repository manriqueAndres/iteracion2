package iteracion2.application;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import iteracion2.models.UpdatableUserInfoEnum;


public class ClientTcp {
	private static final Scanner SCANNER = new Scanner(System.in);

	public static final String SERVER = "localhost";
	public static final int PORT = 3400;
	
	private PrintWriter toNetwork;
	private BufferedReader fromNetwork;
	
	private Socket clientSideSocket;

	public   ClientTcp() {
		System.out.println("Echo TCP client is running ...");
	}

	public void init() throws Exception {

		while(true) {
			try {
			protocol(clientSideSocket);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

		}
	}

	public void protocol(Socket socket) throws Exception {	
			showMainMenu();
			Integer choosedOption = Integer.parseInt(SCANNER.nextLine());
			if (choosedOption != 7) {

				String contentToSend = makeContentToSend(choosedOption);
				sendMessageToServer(contentToSend);
				
			}else {
				String commandsFilePath = getFilePath();
				if (commandsFilePath.isEmpty()) {
					System.out.println("ocurrio un error al leer la ruta del archivo");
				}else {
					System.out.println(commandsFilePath);
					ArrayList<String> commands = getCommandsFromTextFile(commandsFilePath);
					commands.forEach((String command) -> {
						try {
							sendMessageToServer(command);
						} catch (Exception e) {
							e.printStackTrace();
						}
					});
				}
			}
}
	private ArrayList<String> getCommandsFromTextFile(String commandsFilePath) throws IOException {
		
		ArrayList<String> commandList = new ArrayList<>();
	
		BufferedReader reader = new BufferedReader(new FileReader(commandsFilePath));
		String line = reader.readLine();
		while (line != null) {
			 commandList.add(line);
             line = reader.readLine();
		}
		reader.close();
		return commandList;
	}

	private void sendMessageToServer(String contentToSend) throws Exception {
				startClientConection();
				toNetwork.println(contentToSend);
				String fromServer = fromNetwork.readLine();
				System.out.println("[Client] From server: " + fromServer);
				closeClientConection();
		
	}

	private String getFilePath() {
		// TODO Auto-generated method stub
		JFileChooser fileChooser = new JFileChooser();
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Text files", "txt");
        fileChooser.setFileFilter(filter);
        int result = fileChooser.showOpenDialog(null);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFile = fileChooser.getSelectedFile();
            return selectedFile.getAbsolutePath();
        }
		return "";
	}

	private void closeClientConection() throws IOException {
			clientSideSocket.close();
		
	}

	private void startClientConection() throws Exception {
		clientSideSocket = new Socket(SERVER, PORT);
		createStreams(clientSideSocket);
		
	}

	private String makeContentToSend(Integer choosedOption) {
		switch (choosedOption) {
		case 1: {return getRegisterInfo();}
		case 2: {return getModifyAccountInfo();}
		case 3: {return getRemoveAccountInfo();}
		case 4: {return getIncrementMoneyInfo();}
		case 5: {return getTranferMoneyInfo();}
		case 6: {return getWithdrawMoneyInfo();}
		default:
		}
		return "none";
	}

	private String getWithdrawMoneyInfo() {
		String withdrawMoneyParams = "";
		System.out.println("\n---------------------------------------------------------");
		System.out.println("\n------------menu de retiro de dinero ------------");
		System.out.println("\n---------------------------------------------------------");
		
		System.out.println("escriba la cedula del titular de la cuenta");
		String titularId = SCANNER.nextLine();

		System.out.println("Ingrese el numero de cuenta");
		String accountNumber = SCANNER.nextLine();

		System.out.println("Escriba  el monto a retirar ");
		String amount = SCANNER.nextLine();
		System.out.println("Escriba la clave de la cuenta");
		String password = SCANNER.nextLine();
		withdrawMoneyParams = "withdrawMoney,"+titularId+","+accountNumber+","+amount+","+password;
		
		return withdrawMoneyParams;	
	}

	private String getTranferMoneyInfo() {
		String transferMoneyParams = "";
		System.out.println("\n---------------------------------------------------------");
		System.out.println("\n------------menu de transferencia de dinero------------");
		System.out.println("\n---------------------------------------------------------");
		
		System.out.println("Ingrese el numero de la cuenta destino");
		String destinationAccountNumber = SCANNER.nextLine();

		System.out.println("Escriba  el monto a transferir ");
		String amount = SCANNER.nextLine();
		System.out.println("escriba el numero de la cuenta de origen");
		String originAccountNumber = SCANNER.nextLine();
		System.out.println("escriba la clave de la cuenta de origen");
		String password = SCANNER.nextLine();
		transferMoneyParams = "transferMoney,"+destinationAccountNumber+","+amount+","+originAccountNumber+","+password;
		
		return transferMoneyParams;	
	}

	private String getIncrementMoneyInfo() {
		String incrementMoneyParams = "";
		System.out.println("\n---------------------------------------------------------");
		System.out.println("\n------------menu de eliminacion de cuenta------------");
		System.out.println("\n---------------------------------------------------------");
		
		System.out.println("Ingrese el numero de cuenta");
		String accountNumber = SCANNER.nextLine();

		System.out.println("escriba la cedula del titular de la cuenta");
		String titularId = SCANNER.nextLine();
		System.out.println("Escriba  el monto a incrementar ");
		String amount = SCANNER.nextLine();
		incrementMoneyParams = "incrementMoney,"+accountNumber+","+titularId+","+amount;
		
		return incrementMoneyParams;	
		}

	private String getRemoveAccountInfo() {
		String deleteUserParams = "";
		System.out.println("\n---------------------------------------------------------");
		System.out.println("\n------------menu de eliminacion de cuenta------------");
		System.out.println("\n---------------------------------------------------------");
		
		System.out.println("Ingrese el numero de cuenta a cancelar");
		String accountNumber = SCANNER.nextLine();

		System.out.println("escriba el motivo de la cancelacion");
		String deleteReason = SCANNER.nextLine();
		System.out.println("Escriba  su clave ");
		String password = SCANNER.nextLine();
		deleteUserParams = "delete,"+accountNumber+","+deleteReason+","+password;
		
		return deleteUserParams;
	}

	private String getModifyAccountInfo() {
		String updateInfo = "";
		System.out.println("\n---------------------------------------------------------");
		System.out.println("\n------------menu de modificacion de cuenta------------");
		System.out.println("\n---------------------------------------------------------");
		System.out.println("Ingrese su clave");
		String clave = SCANNER.nextLine();

		System.out.println("escriba el atributo que desea cambiar, atributos cambiables:");
		for (UpdatableUserInfoEnum infoUpdatable : UpdatableUserInfoEnum.values()) {
		System.out.println((infoUpdatable+"").toLowerCase());
		}
		System.out.println("------------------------------------------------------------");
		String userInformationToChange = SCANNER.nextLine();
		System.out.println("Escriba  su nuevo "+userInformationToChange);
		String newValue = SCANNER.nextLine();
		updateInfo = "update,"+clave+","+userInformationToChange+","+newValue;
		
		return updateInfo; 
	}

	private String getRegisterInfo() {
		String registerInfo = "";
		System.out.println("\n---------------------------------------------------------");
		System.out.println("\n------------------Menu de creacion de cuenta");
		System.out.println("\n---------------------------------------------------------");
		System.out.println("Ingrese sus nombres");
		String names = SCANNER.nextLine();
		System.out.println("Ingrese sus apellidos");
		String lastNames = SCANNER.nextLine();
		System.out.println("Ingrese su cedula");
		String id = SCANNER.nextLine();
		System.out.println("Ingrese el monto con el que iniciara la cuenta");
		Double startingAmount = Double.parseDouble(SCANNER.nextLine());
		System.out.println("Ingrese  la clave de la cuenta");
		String password = SCANNER.nextLine();
		System.out.println("Ingrese  el correo asosiado a la cuenta");
		String email = SCANNER.nextLine();
		
		
		
		registerInfo = "register,"+names+","+lastNames+","+id+","+startingAmount+","+password+","+email;
		
		return registerInfo; 

	} private void showMainMenu() {
		System.out.println("------------------------------------");
		System.out.println("------------Menu principal----------");
		System.out.println("------------------------------------");
		System.out.println("1:abrir cuenta");
		System.out.println("2:modificar informacion de la cuenta");
		System.out.println("3:eliminar cuenta");
		System.out.println("4:incrementar saldo");
		System.out.println("5:transferir dinero");
		System.out.println("6:retirar dinero");
		System.out.println("7:cargar datos de prueba");
		
	}

	private void createStreams(Socket socket) throws Exception {
		toNetwork = new PrintWriter(socket.getOutputStream(), true);
		fromNetwork = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	}
	public static void main(String args[]) throws Exception {
		ClientTcp ec = new ClientTcp();
		ec.init();
	}

}
